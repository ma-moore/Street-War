import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class extendedCourseWork extends PApplet {

/*
Welcome to my game, tentatively titled Bad Guys Inc (I couldn't really think of anything)
The program is simple to operate, arrow keys to move, spacebar to fire. It is a basic survival game, see how long you can last against
increasing waves of enemies. The challenge really ramps up as the number of 'bombers increase, bringing chaos with them.

The game was made with reference to code examples in the lectures, assigned texts, and the website Processing.org. 
I borrowed the idea of a 'corner map' and the operations of the enemy soldiers/the movement controls
from what I had developed making a version of Pacman from another assignment. The game has been included in the data folder for reference.
Beyond some basics of controls the two games are not similar. 
*/



float x,y,pX,pY; //Percentages used for measurement of entire game, designed to keep it consistent at any size
Player player1; //Named player1 due to an early plan to make the game 2 player, a development that would be relatively easy to set up from the current code
Enemies wave; //new objectes of Enemies are assigned to wave as each wave is defeated, each with more enemies to fight
int currentWave, noSoldiers, noBombers, score, gameStatus; //These variables keep track of progress in the game and increase the difficulty, basic numbers so I used int
Soldier exampleSoldier; //examples used to show players what to expect
BomberMan exampleBomberMan; 
PImage bgMap; //Map made in photoshop with reference (looking at but no copying) to other pixel games like the Pokemon franchise

public void setup ()
{
  size(500,500); //Apparently unable to change overall size of program during run time (in draw), may need to recall setup if wanting to proceed with that
  background(255);
  x=width/100; //basic percentage of size used for a lot of calculations
  y=height/100;
  pX=10*x; //'Pixel Size', size of characters and main measure used for grid
  pY=10*y;
  gameStatus=0; //gameStatus variable used to change between opening screen of game, gameplay, and the end screen
  setupCorners(); //sets up the array of Corners that is the heart of all motion controls in the game
  exampleSoldier = new Soldier(); //briefly used to show players what they will be facing when they start the game
  exampleBomberMan = new BomberMan();
  bgMap=loadImage("mapArt.gif"); //Original map made in processing, then taken into photoshop to give it a better look
}

public void setupGameVariables() //Quick activation of all game variables (that need be reset after 'setup'), allows for the game to be retried easily
{
  player1 = new Player(45*x,10*y);
  currentWave=1;
  noSoldiers=3;
  noBombers=1;
  score=0;
  wave = new Enemies(noSoldiers,noBombers);
}

public void draw()
{
  if (gameStatus==0) //Starting state of the game, can be returned to if the player wants to retry
  {
    startScreen();
  }
  else if (gameStatus==1) //'action' state of the game, where everything happens
  {
    background(255);
    player1.move();
    player1.teleport();
    wave.move(); //most of the enemy actions are neatly contained within the Enemies class, including that of the two types of enemies
    wave.waveDefeated();
    if(player1.attack.direction>0)
    {
      player1.attack.move();
      player1.attack.hitCorner();
      player1.attack.drawBullet();
    }
    player1.drawPlayer();
    if (wave.defeated)
    {
      currentWave++;
      noSoldiers+=2;
      noBombers+=0.5f;
      wave = new Enemies(noSoldiers,noBombers); //Sets up the new wave of enemies, more deadly than the last
    }
    image(bgMap,0,0,width,height);
  }
  else
  {
    endScreen(); //final screen for when you lose, you only have one life to raise the challenge level
  }
}

public void startScreen() //basic start screen with Greeting text and instructions of how to play
{
  background(0);
  fill(255);
  textSize(1.5f*pY);
  text("Welcome!",1.4f*pX,2*pY);
  textSize(0.4f*pY);
  fill(200);
  text("Test yourself against waves of Enemies!",1.25f*pX,3*pY);
  text("Combat Soldiers and deadly Bomber Men.",pX,3.7f*pY);
  text("Soldiers:",3*pX,5*pY);
  text("Bomber Men:",3*pX,6*pY);
  text("Use the Arrow Keys to control,",2*pX,7*pY);
  text("and press the Spacebar to Fire.",2*pX,8*pY);
  fill (255);
  textSize(0.6f*pY);
  text("--Press the Spacebar to begin--",0.3f*pX,9.5f*pY); //originally had this flashing but it looked tacky
  
  exampleSoldier.posX = 6*pX;
  exampleSoldier.posY = 4.1f*pY;
  exampleSoldier.direction = 0;
  exampleSoldier.drawSoldier(); //draws an example of the Soldier Class enemy as a mini tutorial
  
  exampleBomberMan.posX = 6*pX;
  exampleBomberMan.posY = 5.15f*pY;
  exampleBomberMan.direction = 0;
  exampleBomberMan.drawBomberMan(); //draws an example of the Bomber Class enemy as a mini tutorial
}

public void endScreen() //Basic finish screen showing how well the player did and giving them the option to play again
{
  background(0);
  fill(255);
  textSize(50);
  text("Game Over",2*pX,2*pY);
  textSize(25);
  text("Your score is: "+score,pX,3.5f*pY);
  text("You survived "+currentWave+" waves of enemies",pX,4.5f*pY);
  text("Press the Spacebar to try again",pX,5.5f*pY);
}
  


class Bomb //Primary weapon of the bomberman class. Its explosions make large sections of the board deadly
{
  float posX=0;
  float posY=0;
  boolean placed=false; //important to make sure the same bomberMan doesn't place too many bombs at once and that the player isn't killed by expired bombs
  int fuse=0; //counter times how long the bomb takes to full explode and how long it lasts for
  int corner; //what corner the bomb is placed at, can only be placed at a corner for simplicity. 
  float upY,downY,leftX,rightX; //the paramaters of the explosion
  float speed=0.5f*x; //fast moving bomb, near impossible for the player to outrun if they aren't careful
  boolean blockedUp,blockedDown,blockedRight,blockedLeft; //needed to stop the bomb going through walls.
  
  public void drawBomb()
  {
    if ((fuse%8)==0) //Bomb's colour flashes to make it look more like an explosion
    {
      fill (255,0,0);
    }
    else
    {
      fill(100,0,0);
    }
    ellipse(posX+(0.5f*pX),posY+(0.5f*pY),0.4f*pX,0.4f*pY); //the basic bomb, quickly taken over by the explosion
    fuse++;
  }
  
  public void placeBomb() //used by the Bomberman class randomly when it reaches the corner, effectively sets up the Bombs variables
  {
    placed=true;
    upY=corners[corner].posY;
    downY=corners[corner].posY;
    leftX=corners[corner].posX;
    rightX=corners[corner].posX;
    fuse=0;
    blockedUp=false;
    blockedDown=false;
    blockedRight=false;
    blockedLeft=false;
  }
  
  public void explode()
  {
    noStroke();
    if (fuse>10&&fuse<=20) //basic animation steps as the bomb expands
    {
      ellipse(posX+(0.5f*pX),posY+(0.5f*pY),0.6f*pX,0.6f*pY);
    }
    if (fuse>20&&fuse<=30)
    {
      ellipse(posX+(0.5f*pX),posY+(0.5f*pY),0.8f*pX,0.8f*pY);
    }
    if (fuse>30&&fuse<=40)
    {
      ellipse(posX+(0.5f*pX),posY+(0.5f*pY),pX,pY);
    }
    if (fuse>40)
    {
      rect(posX,posY,pX,pY); 
    }
    if (fuse>50)
    {
      rectMode(CORNERS);
      if (corners[corner].up) //explosion proper, checks what direction it can explode in, the proceeds down the corridor till it hits a corner, then stays till the timer expires
      {
        for (int i=0;i<corners.length;i++)
        {
          if (i!=corner)
          {
            if ((posX<corners[i].posX+(3*x))&&(posX>corners[i].posX-(3*x))&&(upY<corners[i].posY+(2*y))&&(upY>corners[i].posY-(2*y)))
            {
              if(!corners[i].up)
              {
                blockedUp=true;
              }
            }
          }
        }
        if (!blockedUp)
        {
          upY-=speed;
        }
        rect(posX,upY-(2*x),posX+pX,posY+pY);
      }
      if (corners[corner].down)
      {
        for (int i=0;i<corners.length;i++)
        {
          if (i!=corner)
          {
            if ((posX<corners[i].posX+(2*x))&&(posX>corners[i].posX-(2*x))&&(downY<corners[i].posY+(2*y))&&(downY>corners[i].posY-(2*y)))
            {
              if (!corners[i].down)
              {
                blockedDown=true;
              }
            }
          }
        }
        if (!blockedDown)
        {
          downY+=speed;
        }
        rect(posX,posY,posX+pX,downY+(1.2f*pY));
      }
      if (corners[corner].right)
      {
        for (int i=0;i<corners.length;i++)
        {
          if (i!=corner)
          {
            if ((rightX<corners[i].posX+(2*x))&&(rightX>corners[i].posX-(2*x))&&(posY<corners[i].posY+(2*y))&&(posY>corners[i].posY-(2*y)))
            {
              if (!corners[i].right)
              {
                blockedRight=true;
              }
            }
          }
        }
        if (!blockedRight)
        {
          rightX+=speed;
        }
        rect(posX,posY,rightX+(1.2f*pX),posY+pY);
      }
      if (corners[corner].left)
      {
        for (int i=0;i<corners.length;i++)
        {
          if(i!=corner)
          {
            if ((leftX<corners[i].posX+(2*x))&&(leftX>corners[i].posX-(2*x))&&(posY<corners[i].posY+(2*y))&&(posY>corners[i].posY-(2*y)))
            {
              if (!corners[i].left)
              {
                blockedLeft=true;
              }
            }
          }
        }
        if (!blockedLeft)
        {
          leftX-=speed;
        }
        rect(leftX-(2*x),posY,posX+pX,posY+pY);
      }
    }
    if (fuse>200) //bomb expires and can be placed again
    {
      placed=false;
    }
    rectMode(CORNER);
  }
}
/*
  Bomber class enemies, moves randomly and places bombs that explode devestating a large area of the map
*/


class BomberMan
{
  float posX = entry.posX;
  float posY = entry.posY-pY;
  int direction = 3; //Starting direction of the bomber, starts downward, emerges from the 'Entrance' before moving around the maze
  float speed = 0.2f*x; //slow speed to avoid catching the player too easily
  boolean alive = true;
  Bomb attack = new Bomb();
  PImage up = loadImage("bomberUp.gif");
  PImage down = loadImage("bomberDown.gif");
  PImage right = loadImage("bomberRight.gif");
  PImage left = loadImage("bomberLeft.gif");
  
  public void drawBomberMan() //Draws the enemy 
  {
    if (direction==1)
    {
      image(up,posX,posY,pX,pY);
    }
    else if (direction==0||direction==2)
    {
      image(right,posX,posY,pX,pY);
    }
    else if (direction==3)
    {
      image(down,posX,posY,pX,pY);
    }
    else if (direction==4)
    {
      image(left,posX,posY,pX,pY);
    }
  }
  
  public void victory() //if the bomberMan's bomb hits the player the game is over
  {
    if ((player1.posY>(attack.upY-y))&&(player1.posY<(attack.downY+pY))&&(player1.posX>(attack.posX-(5*x)))&&(player1.posX<(attack.posX+(5*x))))
    {
      gameStatus=2;
    }
    else if ((player1.posX>(attack.leftX-x))&&(player1.posX<(attack.rightX+pX))&&(player1.posY>(attack.posY-(5*y)))&&(player1.posY<(attack.posY+(5*y))))
    {
      gameStatus=2;
    }
  }
  
  public void kill() //places a bomb at random when it hits a corner, but can only place if it hasn't already placed one
  {
    for (int i=0; i<corners.length;i++)
    {
      if (!attack.placed)
      {
        if ((posX<corners[i].posX+(speed))&&(posX>corners[i].posX-(speed))&&(posY<corners[i].posY+(speed))&&(posY>corners[i].posY-(speed)))
        {
          if (random(0,10)>5)
          {
            attack.posX=corners[i].posX;
            attack.posY=corners[i].posY;
            attack.corner=i;
            attack.placeBomb();
          }
        }
      }
    }
  }
  
  public void killed() //if the player's bullets hit it
  {  
    if ((player1.attack.posX>posX-(4*x))&&(player1.attack.posX<(posX+(4*x)))&&(player1.attack.posY>posY-(4*x))&&(player1.attack.posY<=(posY+(4*y))))
    {
      alive=false;
      player1.attack.posX = 0;
      player1.attack.posY = 0;
      player1.attack.direction = 0;
      player1.attack.fired = false;
      score+=20;
    }
  }
  
  public void teleport() //loops the map in on itself
  {
    if (posX>width)
    {
      posX=0-pX;
    }
    else if (posX<(0-pX))
    {
      posX=width;
    }
    if (posY>height)
    {
      posY=0-pY;
    }
    else if (posY<(0-pY))
    {
      posY=height;
    }
  }
  
  public void move() 
  {
    if (direction==1)
    {
      posY-=speed;
    }
    else if (direction==2)
    {
      posX+=speed;
    }
    else if (direction==3)
    {
      posY+=speed;
    }
    else if (direction==4)
    {
      posX-=speed;
    }
  }
  
  public void changeDirection() //moves at random when it hits a corner, can only proceed foreward.
  {
    if ((posX==entry.posX)&&(posY>entry.posY-y)&&(posY<entry.posY-1))
    {
      if ((random(-10,10))>0)
      {
        direction=4;
      }
      else
      {
        direction=2;
      }
      posY = entry.posY;
    }
    
    for (int i=0;i<corners.length;i++)
    {
      if ((posX<corners[i].posX+(speed))&&(posX>corners[i].posX-(speed))&&(posY<corners[i].posY+(speed))&&(posY>corners[i].posY-(speed)))
      {
        if (direction==1)
        {
          if (corners[i].up)
          {
            if ((random(-10,10))>0)
            {
              if (corners[i].right)
              {
                direction=2;
              }
              else if (corners[i].left)
              {
                direction=4;
              }
            }
          }
          else
          {
            if (corners[i].left&&corners[i].right)
            {
              if ((random(-10,10))>0)
              {
                direction=4;
              }
              else
              {
                direction=2;
              }
            }
            else if (corners[i].right)
            {
              direction=2;
            }
            else if (corners[i].left)
            {
              direction=4;
            }
          }
        }
        else if (direction==2)
        {
          if (corners[i].right)
          {
            if ((random(-10,10))>0)
            {
              if (corners[i].up)
              {
                direction=1;
              }
              else if (corners[i].down)
              {
                direction=3;
              }
            }
          }
          else
          {
            if (corners[i].up&&corners[i].down)
            {
              if ((random(-10,10))>0)
              {
                direction=1;
              }
              else
              {
                direction=3;
              }
            }
            else if (corners[i].up)
            {
              direction=1;
            }
            else if (corners[i].down)
            {
              direction=3;
            }
          }
        }
        else if (direction==3)
        {
          if (corners[i].down)
          {
            if ((random(-10,10))>0)
            {
              if (corners[i].right)
              {
                direction=2;
              }
              else if (corners[i].left)
              {
                direction=4;
              }
            }
          }
          else
          {
            if (corners[i].left&&corners[i].right)
            {
              if ((random(-10,10))>0)
              {
                direction=4;
              }
              else 
              {
                direction=2;
              }
            }
            else if (corners[i].left)
            {
              direction=4;
            }
            else if (corners[i].right)
            {
              direction=2;
            }
          }
        }
        else if (direction==4)
        {
          if (corners[i].left)
          {
            if ((random(-10,10))>0)
            {
              if (corners[i].up)
              {
                direction=1;
              }
              else if (corners[i].down)
              {
                direction=3;
              }
            }
          }
          else
          {
            if (corners[i].up&&corners[i].down)
            {
              if ((random(-10,10))>0)
              {
                direction=1;
              }
              else
              {
                direction=3;
              }
            }
            else if (corners[i].up)
            {
              direction=1;
            }
            else if (corners[i].down)
            {
              direction=3;
            }
          }
        }
      }
    }
  }
}


class Bullet //Weapon used by soldiers and players alike, keeps going till it hits a corner, can only be fired once (deliberate to increase challenge)
{
  float posX = 0;
  float posY = 0;
  int direction = 0;
  float speed = 0.3f*x;
  boolean fired = false;
  PImage shot = loadImage("bullet.gif");
  
  public void move()
  {
    if (direction==1)
    {
      posY-=speed;
    }
    else if (direction==2)
    {
      posX+=speed;
    }
    else if (direction==3)
    {
      posY+=speed;
    }
    else if (direction==4)
    {
      posX-=speed;
    }
  }
  
  public void hitCorner()
  {
    boolean shotOver=false;
    for (int i=0; i<corners.length;i++)
    {
      if ((posX<corners[i].posX+(speed))&&(posX>corners[i].posX-(speed))&&(posY<corners[i].posY+(speed))&&(posY>corners[i].posY-(speed)))
      {
        if (((direction==1)&&(!corners[i].up))||((direction==2)&&(!corners[i].right))||((direction==3)&&(!corners[i].down))||((direction==4)&&(!corners[i].left)))
        {
          shotOver=true;
        }
      }
    }
    if ((posX>width)||(posX<(0-pX))||(posY>height)||(posY<(0-pY)))
    {
      shotOver=true;
    }
    if (shotOver)
    {
      posX = 0;
      posY = 0;
      direction = 0;
      fired = false;
    }
  }
  
  public void drawBullet()
  {
    image(shot,posX,posY,pX,pY);
  }
}


/*This could be set up as an Array but given the amount of information each corner needs to hold it is easier this way
Corner notes:
  - 20 Corners total
  - +1 Entry 'corner'
  - Idea borrowed from pacman game previously developed, though more effectively deployed here
*/

Corner[] corners; //Array allows easy check of corners throughout the program
Corner entry; //Only of use once, no need for it to be part of the general array

public void setupCorners()
{
  corners = new Corner[20];
  corners[0] = new Corner(pX*2,pY,false,true,true,false); //Quickest way to initialise the corners, had to do each individually, no feasible way to do it with a for loop
  corners[1] = new Corner(pX*3,pY,true,true,false,true);
  corners[2] = new Corner(pX*6,pY,true,true,false,true);
  corners[3] = new Corner(pX*7,pY,false,false,true,true);
  corners[4] = new Corner(pX,pY*2,false,true,true,true);
  corners[5] = new Corner(pX*2,pY*2,true,false,false,true);
  corners[6] = new Corner(pX*7,pY*2,true,true,false,false);
  corners[7] = new Corner(pX*8,pY*2,false,true,true,true);
  corners[8] = new Corner(pX*3,pY*4,false,true,true,false);
  corners[9] = new Corner(pX*6,pY*4,false,false,true,true);
  corners[10] = new Corner(pX,pY*5,true,true,false,false);
  corners[11] = new Corner(pX*3,pY*5,true,false,true,true);
  corners[12] = new Corner(pX*6,pY*5,true,true,true,false);
  corners[13] = new Corner(pX*8,pY*5,true,false,false,true);
  corners[14] = new Corner(pX*3,pY*6,true,true,true,false);
  corners[15] = new Corner(pX*6,pY*6,true,false,true,true);
  corners[16] = new Corner(pX*3,pY*7,true,false,true,true);
  corners[17] = new Corner(pX*6,pY*7,true,true,true,false);
  corners[18] = new Corner(pX*3,pY*8,true,true,true,false);
  corners[19] = new Corner(pX*6,pY*8,true,false,true,true);
  entry = new Corner(pX*4.5f,pY*4,false,true,false,true); //Means for enemies to enter the maze
}

public void drawCorners() //Useful function to visually see where the corners are checked while programming, unnecessary once program is complete
{
  for(int i=0; i<corners.length; i++)
  {
    corners[i].drawCorner();
  }
  entry.drawCorner();
}

class Corner //Basic Object for each class, allows the x and y coordinates to be tied to each corner, as well as the directions that are available
{
  float posX,posY;
  boolean up, down, right, left;
  
  Corner(float a, float b, boolean u, boolean r, boolean d, boolean l)
  {
    posX = a;
    posY = b;
    up = u;
    down = d;
    right = r;
    left = l;
  }
  
  public void drawCorner() //Useful function to visually see where the corners are checked while programming, unnecessary once program is complete
  {
    fill(255,255,0);
    ellipse(posX,posY,2*x,2*y);
  }
}


class Enemies //Enemy class calls up arrays of bombermen and soldiers that can be varied to increase challenge, also sets up movement etc variables
{
  Soldier[] soldiers;
  BomberMan[] bomberMen;
  boolean defeated;
  int time = 0;
  Enemies (int s, int b)
  {
    soldiers = new Soldier[s];
    for (int i=0;i<soldiers.length;i++)
    {
      soldiers[i] = new Soldier();
    }
    bomberMen = new BomberMan[b];
    for (int i=0;i<bomberMen.length;i++)
    {
      bomberMen[i] = new BomberMan();
    }
  }
    
  
  public void move()
  {
    for (int i=0;i<soldiers.length;i++)
    {
      if (soldiers[i].alive)
      {
        soldiers[i].move();
        soldiers[i].changeDirection();
        soldiers[i].teleport();
        soldiers[i].killed();
        soldiers[i].kill();
        if(soldiers[i].attack.direction>0)
        {
          soldiers[i].attack.move();
          soldiers[i].attack.hitCorner();
          soldiers[i].attack.drawBullet();
          soldiers[i].victory();
        }
        soldiers[i].drawSoldier();
      }
    }
    for (int i=0; i<soldiers.length;i++)
    {
      if (time<((i*300)+90))
      {
        soldiers[i].posX = entry.posX;
        soldiers[i].posY = entry.posY-pY;
      }
    }
    for (int i=0; i<bomberMen.length;i++)
    {
      if (bomberMen[i].alive)
      {
        bomberMen[i].drawBomberMan();
        bomberMen[i].move();
        bomberMen[i].changeDirection();
        bomberMen[i].teleport();
        bomberMen[i].killed();
        bomberMen[i].kill();
        if(bomberMen[i].attack.placed)
        {
          bomberMen[i].attack.drawBomb();
          bomberMen[i].attack.explode();
          bomberMen[i].victory();
        }
      }
    }
    for (int i=0; i<bomberMen.length;i++)
    {
      if (time<((i*300)+120))
      {
        bomberMen[i].posX = entry.posX;
        bomberMen[i].posY = entry.posY-pY;
      }
    }
    time++;
  }
  
  public void waveDefeated() //moves on to next wave when all troops are dead
  {
    defeated=true;
    for (int i=0;i<soldiers.length;i++)
    {
      if (soldiers[i].alive)
      {
        defeated=false;
      }
    }
    for (int i=0;i<bomberMen.length;i++)
    {
      if (bomberMen[i].alive)
      {
        defeated=false;
      }
    }
  }
  
}
    


class Player //Sets up the player class. Contains image, attack and movement options for the player character.
{
  PImage up = loadImage("playerUp.gif");
  PImage down = loadImage("playerDown.gif");
  PImage right = loadImage("playerRight.gif");
  PImage left = loadImage("playerLeft.gif");
  float posX, posY;
  int direction = 0; //Starting direction of the player, starts at a rest (0) (at this stage the only directions available are left and right)
  float speed = 0.3f*x; //speed of the player can be change easily from one point, or increased as levels increase
  int playerColor; //player colour, useful for differentiating the player colours)
  Bullet attack;
  
  Player (float a, float b) //Player position is declared when the object is created, this allows for the game to be set up as a two player game 
  {
    posX = a;
    posY = b;
    attack = new Bullet();
  }
  
  public void drawPlayer() //Draws the player character, 
  {
    if (direction==1)
    {
      image(up,posX,posY,pX,pY);
    }
    else if (direction==0||direction==2)
    {
      image(right,posX,posY,pX,pY);
    }
    else if (direction==3)
    {
      image(down,posX,posY,pX,pY);
    }
    else if (direction==4)
    {
      image(left,posX,posY,pX,pY);
    }
  }
  
  public void fire()
  {
    attack.posX = posX;
    attack.posY = posY;
    attack.direction = direction;
    attack.fired = true;
  }
    
  public void teleport()
  {
    if (posX>width)
    {
      posX=0-pX;
    }
    else if (posX<(0-pX))
    {
      posX=width;
    }
    if (posY>height)
    {
      posY=0-pY;
    }
    else if (posY<(0-pY))
    {
      posY=height;
    }
  }
  
  public void move()
  {
    boolean blocked=false; //Player character moves as long as it is not blocked
    if (direction == 1)
    {
      for(int i=0;i<corners.length;i++) //Checks to see if the player is at any corner
      {
        if ((posX>corners[i].posX-(3*x))&&(posX<corners[i].posX+(3*x))&&(posY>corners[i].posY-y)&&(posY<corners[i].posY+y))//Checks to see if the player is at any corner
        {
          if(!corners[i].up)
          {
            blocked=true; //Tells the function that the player can't move further
            posY=corners[i].posY; //Used to make sure the player remains in the correct channels
          }
        }
      }
      if (!blocked) 
      {
        posY-=speed; //Keeps the player moving if they are not blocked
      }        
    }
    else if (direction == 2)
    {
      for(int i=0;i<corners.length;i++) //Checks to see if the player is at any corner
      {
        if ((posX>corners[i].posX-x)&&(posX<corners[i].posX+x)&&(posY>corners[i].posY-(3*y))&&(posY<corners[i].posY+(3*y)))//Checks to see if the player is at any corner
        {
          if(!corners[i].right)
          {
            blocked=true; //Tells the function that the player can't move further
            posX=corners[i].posX; //Used to make sure the player remains in the correct channels
          }
        }
      }
      if(!blocked)
      {
        posX+=speed; //Keeps the player moving if they are not blocked
      }
    }
    else if (direction == 3)
    {
      for(int i=0;i<corners.length;i++) //Checks to see if the player is at any corner
      {
        if ((posX>corners[i].posX-(3*x))&&(posX<corners[i].posX+(3*x))&&(posY>corners[i].posY-y)&&(posY<corners[i].posY+y)) //Checks to see if the player is at any corner
        {
          if(!corners[i].down)
          {
            blocked=true; //Tells the function that the player can't move further
            posY=corners[i].posY; //Used to make sure the player remains in the correct channels
          }
        }
      }
      if(!blocked)
      {
        posY+=speed; //Keeps the player moving if they are not blocked
      }
    }
    else if (direction == 4)
    {
      for(int i=0;i<corners.length;i++) //Checks to see if the player is at any corner
      {
        if ((posX>corners[i].posX-x)&&(posX<corners[i].posX+x)&&(posY>corners[i].posY-(3*y))&&(posY<corners[i].posY+(3*y))) //Checks to see if the player is at any corner
        {
          if(!corners[i].left)
          {
            blocked=true; //Tells the function that the player can't move further
            posX=corners[i].posX; //Used to make sure the player remains in the correct channels
          }
        }
      }
      if(!blocked)
      {
        posX-=speed; //Keeps the player moving if they are not blocked
      }
    }
  }
}




public void keyPressed()
{
  if (key==CODED) //Movement for player 1 governed by the arrow keys
  {
    if (keyCode==UP)
    {
      for(int i=0;i<corners.length;i++)
      {
        if ((player1.posX>corners[i].posX-(3*x))&&(player1.posX<corners[i].posX+(3*x))&&(player1.posY>corners[i].posY-(3*y))&&(player1.posY<corners[i].posY+(3*y)))
        {
          if(corners[i].up)
          {
            player1.direction=1;
            player1.posX=corners[i].posX;
            player1.posY=corners[i].posY;
          }
        }
        else
        {
          if (player1.direction==3)
          {
            player1.direction=1;
          }
        }
      }
    }
    else if (keyCode==RIGHT)
    {
      for(int i=0;i<corners.length;i++)
      {
        if ((player1.posX>corners[i].posX-(3*x))&&(player1.posX<corners[i].posX+(3*x))&&(player1.posY>corners[i].posY-(3*y))&&(player1.posY<corners[i].posY+(3*y)))
        {
          if(corners[i].right)
          {
            player1.direction=2;
            player1.posX=corners[i].posX;
            player1.posY=corners[i].posY;
          }
        }
        else
        {
          if (player1.direction==4||player1.direction==0)
          {
            player1.direction=2;
          }
        }
      }
    }
    else if (keyCode==DOWN)
    {
      for(int i=0;i<corners.length;i++)
      {
        if ((player1.posX>corners[i].posX-(3*x))&&(player1.posX<corners[i].posX+(3*x))&&(player1.posY>corners[i].posY-(3*y))&&(player1.posY<corners[i].posY+(3*y)))
        {
          if(corners[i].down)
          {
            player1.direction=3;
            player1.posX=corners[i].posX;
            player1.posY=corners[i].posY;
          }
        }
        else
        {
          if (player1.direction==1)
          {
            player1.direction=3;
          }
        }
      }
    }
    else if (keyCode==LEFT)
    {
      for(int i=0;i<corners.length;i++)
      {
        if ((player1.posX>corners[i].posX-(3*x))&&(player1.posX<corners[i].posX+(3*x))&&(player1.posY>corners[i].posY-(3*y))&&(player1.posY<corners[i].posY+(3*y)))
        {
          if(corners[i].left)
          {
            player1.direction=4;
            player1.posX=corners[i].posX;
            player1.posY=corners[i].posY;
          }
        }
        else
        {
          if (player1.direction==2||player1.direction==0)
          {
            player1.direction=4;
          }
        }
      }
    }
  }
  
  if (key == ' ')
  {
    if (gameStatus==0)
    {
      gameStatus=1;
      setupGameVariables();
    }
    else if (gameStatus==1)
    {
      if (!player1.attack.fired&&player1.direction>0)
      {
        player1.fire();
      }
    }
    else if (gameStatus==2)
    {
      gameStatus=0;
    }
  }
}

/*
  Soldier class enemies, operates in a similar way to the player character
  Pursues the Player
*/


class Soldier
{
  PImage up = loadImage("soldierUp.gif");
  PImage down = loadImage("soldierDown.gif");
  PImage right = loadImage("soldierRight.gif");
  PImage left = loadImage("soldierLeft.gif");
  float posX = entry.posX;
  float posY = entry.posY-pY;
  int direction = 3; //Starting direction of the soldier, starts downward, emerges from the 'Entrance' before moving around the maze
  float speed = 0.2f*x; //speed of the soldier can be change easily from one point, or increased as levels increase
  boolean alive = true;
  Bullet attack = new Bullet();
  
  public void drawSoldier() //Draws the soldier 
  {
    if (direction==1)
    {
      image(up,posX,posY,pX,pY);
    }
    else if (direction==0||direction==2)
    {
      image(right,posX,posY,pX,pY);
    }
    else if (direction==3)
    {
      image(down,posX,posY,pX,pY);
    }
    else if (direction==4)
    {
      image(left,posX,posY,pX,pY);
    }
  }
  
  public void victory()
  {
    if ((attack.posX>player1.posX-(2*x))&&(attack.posX<(player1.posX+(1*x)))&&(attack.posY>player1.posY-(2*y))&&(attack.posY<(player1.posY+(4.5f*y))))
    {
      gameStatus=2;
    }
  }
  
  public void kill()
  {
    if (!attack.fired)
    {
      if (direction==1)
      {
        if ((player1.posX>(posX-x))&&(player1.posX<(posX+x))&&(player1.posY<=posY)&&(player1.posY>(posY-(5*pY))))
        {
          attack.direction=1;
          attack.posX=posX;
          attack.posY=posY;
          attack.fired=true;
        }
      }
      else if (direction==2)
      {
        if ((player1.posY>(posY-y))&&(player1.posY<(posY+y)))
        {
          if ((player1.posX>=posX)&&(player1.posX<(posX+(5*pX))))
          {
            attack.direction=2;
            attack.posX=posX;
            attack.posY=posY;
            attack.fired=true;
          }
        }
      }
      else if (direction==3)
      {
        if ((player1.posX>(posX-x))&&(player1.posX<(posX+x)))
        {
          if ((player1.posY>=posY)&&(player1.posY<(posY+(5*pY))))
          {
            attack.direction=3;
            attack.posX=posX;
            attack.posY=posY;
            attack.fired=true;
          }
        }
      }
      else if (direction==4)
      {
        if ((player1.posY>(posY-y))&&(player1.posY<(posY+y)))
        {
          if ((player1.posX<=posX)&&(player1.posX>(posX-(5*pX))))
          {
            attack.direction=4;
            attack.posX=posX;
            attack.posY=posY;
            attack.fired=true;
          }
        }
      }
    }
  }
  
  public void killed()
  {  
    if ((player1.attack.posX>=posX-(4*x))&&(player1.attack.posX<=(posX+(4*x)))&&(player1.attack.posY>=(posY-(4*y)))&&(player1.attack.posY<=(posY+(4*y))))
    {
      alive=false;
      player1.attack.posX = 0;
      player1.attack.posY = 0;
      player1.attack.direction = 0;
      player1.attack.fired = false;
      score+=10;
    }
  }
  
  public void teleport()
  {
    if (posX>width)
    {
      posX=0-pX;
    }
    else if (posX<(0-pX))
    {
      posX=width;
    }
    if (posY>height)
    {
      posY=0-pY;
    }
    else if (posY<(0-pY))
    {
      posY=height;
    }
  }
  
  public void move()
  {
    if (direction==1)
    {
      posY-=speed;
    }
    else if (direction==2)
    {
      posX+=speed;
    }
    else if (direction==3)
    {
      posY+=speed;
    }
    else if (direction==4)
    {
      posX-=speed;
    }
  }
  
  public void changeDirection()
  {
    if ((posX==entry.posX)&&(posY>entry.posY-y)&&(posY<entry.posY))
    {
      if (player1.posX<posX)
      {
        direction=4;
      }
      else
      {
        direction=2;
      }
      posY = entry.posY;
    }
    
    for (int i=0;i<corners.length;i++)
    {
      if ((posX<corners[i].posX+(speed))&&(posX>corners[i].posX-(speed))&&(posY<corners[i].posY+(speed))&&(posY>corners[i].posY-(speed)))
      {
        if (direction==1)
        {
          if (corners[i].up)
          {
            if (player1.posY>posY)
            {
              if (corners[i].right)
              {
                direction=2;
              }
              else if (corners[i].left)
              {
                direction=4;
              }
            }
          }
          else
          {
            if (corners[i].left&&corners[i].right)
            {
              if (player1.posX<posX)
              {
                direction=4;
              }
              else
              {
                direction=2;
              }
            }
            else if (corners[i].right)
            {
              direction=2;
            }
            else if (corners[i].left)
            {
              direction=4;
            }
          }
        }
        else if (direction==2)
        {
          if (corners[i].right)
          {
            if (player1.posX<posX)
            {
              if (corners[i].up)
              {
                direction=1;
              }
              else if (corners[i].down)
              {
                direction=3;
              }
            }
          }
          else
          {
            if (corners[i].up&&corners[i].down)
            {
              if (player1.posY<posY)
              {
                direction=1;
              }
              else
              {
                direction=3;
              }
            }
            else if (corners[i].up)
            {
              direction=1;
            }
            else if (corners[i].down)
            {
              direction=3;
            }
          }
        }
        else if (direction==3)
        {
          if (corners[i].down)
          {
            if (player1.posY<posY)
            {
              if (corners[i].right)
              {
                direction=2;
              }
              else if (corners[i].left)
              {
                direction=4;
              }
            }
          }
          else
          {
            if (corners[i].left&&corners[i].right)
            {
              if (player1.posX<posX)
              {
                direction=4;
              }
              else 
              {
                direction=2;
              }
            }
            else if (corners[i].left)
            {
              direction=4;
            }
            else if (corners[i].right)
            {
              direction=2;
            }
          }
        }
        else if (direction==4)
        {
          if (corners[i].left)
          {
            if (player1.posX>posX)
            {
              if (corners[i].up)
              {
                direction=1;
              }
              else if (corners[i].down)
              {
                direction=3;
              }
            }
          }
          else
          {
            if (corners[i].up&&corners[i].down)
            {
              if (player1.posY<posY)
              {
                direction=1;
              }
              else
              {
                direction=3;
              }
            }
            else if (corners[i].up)
            {
              direction=1;
            }
            else if (corners[i].down)
            {
              direction=3;
            }
          }
        }
      }
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "extendedCourseWork" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
